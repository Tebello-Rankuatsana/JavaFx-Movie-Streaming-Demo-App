module streaming {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;

    opens streaming to javafx.fxml;
    exports streaming;
}
